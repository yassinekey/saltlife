<?php
/**
 * Import remove.
 *
 * @package woodmart
 */

namespace XTS\Admin\Modules\Import;

use Exception;
use XTS\Admin\Modules\Options\Presets;
use XTS\Singleton;

if ( ! defined( 'WOODMART_THEME_DIR' ) ) {
	exit( 'No direct script access allowed' );
}

/**
 * Import remove.
 */
class Remove extends Singleton {
	/**
	 * Categories.
	 *
	 * @var array
	 */
	private $categories;
	/**
	 * Imported versions.
	 *
	 * @var array
	 */
	private $versions;
	/**
	 * $has_data_to_remove.
	 *
	 * @var array
	 */
	private $has_data_to_remove = false;

	/**
	 * Init.
	 */
	public function init() {
		add_action( 'init', array( $this, 'set_categories' ) );

		$this->set_versions();

		add_action( 'wp_ajax_woodmart_import_remove_action', array( $this, 'remove_action' ) );
		add_action( 'wp_ajax_woodmart_import_partial_remove_action', array( $this, 'partial_remove_action' ) );
	}

	/**
	 * Set versions.
	 */
	private function set_versions() {
		$versions = woodmart_get_config( 'versions' );

		foreach ( $versions as $key => $version ) {
			$this->versions[] = $key;

			if ( empty( $version['partial'] ) ) {
				continue;
			}

			foreach ( $version['partial'] as $partial_items ) {
				foreach ( $partial_items as $partial_slug => $partial_item ) {
					$this->versions[] = $partial_slug;
				}
			}
		}
	}

	/**
	 * Remove options in no data to remove.
	 */
	public function remove_options() {
		if ( ! $this->has_data_to_remove ) {
			foreach ( $this->versions as $version ) {
				delete_option( 'wd_imported_data_' . $version );
			}
			delete_option( 'wd_import_imported_versions' );
			delete_option( 'wd_import_replaced_items' );
		}
	}

	/**
	 * Remove action.
	 */
	public function remove_action() {
		check_ajax_referer( 'woodmart-import-remove-nonce', 'security' );

		if ( ! isset( $_GET['data'] ) || ! $_GET['data'] ) { // phpcs:ignore
			return;
		}

		$selected_categories_raw = woodmart_clean( wp_unslash( $_GET['data'] ) ); // phpcs:ignore
		$selected_categories     = array();

		foreach ( $selected_categories_raw as $category ) {
			$selected_categories[] = $category['name'];
		}

		foreach ( $this->versions as $version ) {
			$imported_data = get_option( 'wd_imported_data_' . $version );

			if ( in_array( 'page', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'page' ), $imported_data );
				$current_base  = get_option( 'wd_import_current_base', 'base' );
				delete_option( 'wd_import_imported_versions' );
				update_option( 'wd_import_imported_versions', array( $current_base ), false );

				$this->categories['page']['data'] = array();
			}

			if ( in_array( 'attachment', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'attachment' ), $imported_data );

				$this->categories['attachment']['data'] = array();
			}

			if ( in_array( 'woodmart_layout', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'woodmart_layout' ), $imported_data );

				$this->categories['woodmart_layout']['data'] = array();
			}

			if ( in_array( 'headers', $selected_categories, true ) ) {
				$imported_data = $this->delete_headers( $imported_data );

				$this->categories['headers']['data'] = array();
			}

			if ( in_array( 'woodmart_slider', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms( array( 'woodmart_slider' ), $imported_data );
				$imported_data = $this->delete_posts( array( 'woodmart_slide' ), $imported_data );

				$this->categories['woodmart_slider']['data'] = array();
			}

			if ( in_array( 'post', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms( array( 'category', 'post_tag' ), $imported_data );
				$imported_data = $this->delete_posts( array( 'post' ), $imported_data );

				$this->categories['post']['data'] = array();
			}

			if ( in_array( 'portfolio', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms( array( 'project-cat' ), $imported_data );
				$imported_data = $this->delete_posts( array( 'portfolio' ), $imported_data );

				$this->categories['portfolio']['data'] = array();
			}

			if ( in_array( 'product', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms(
					array(
						'product_cat',
						'product_brand',
						'pa_brand',
						'pa_color',
						'pa_size',
					),
					$imported_data
				);
				$imported_data = $this->delete_posts(
					array(
						'product',
						'product_variation',
						'woodmart_size_guide',
						'woodmart_woo_lv',
						'woodmart_woo_fbt',
						'wd_woo_discounts',
						'wd_product_tabs',
						'wd_custom_label',
					),
					$imported_data
				);

				$this->categories['product']['data'] = array();
			}

			if ( in_array( 'cms_block', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'cms_block' ), $imported_data );

				$this->categories['cms_block']['data'] = array();
			}

			if ( in_array( 'nav_menu', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms( array( 'nav_menu' ), $imported_data );
				$imported_data = $this->delete_posts( array( 'nav_menu_item' ), $imported_data );

				$this->categories['nav_menu']['data'] = array();
			}

			if ( in_array( 'mc4wp-form', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'mc4wp-form' ), $imported_data );

				$this->categories['mc4wp-form']['data'] = array();
			}

			if ( in_array( 'wpcf7_contact_form', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'wpcf7_contact_form' ), $imported_data );

				$this->categories['wpcf7_contact_form']['data'] = array();
			}

			if ( in_array( 'presets', $selected_categories, true ) ) {
				$this->delete_presets();

				$this->categories['presets']['data'] = array();
			}

			if ( in_array( 'wd_floating_block', $selected_categories, true ) ) {
				$imported_data                                 = $this->delete_posts( array( 'wd_floating_block' ), $imported_data );
				$this->categories['wd_floating_block']['data'] = array();
			}

			if ( in_array( 'wd_popup', $selected_categories, true ) ) {
				$imported_data                        = $this->delete_posts( array( 'wd_popup' ), $imported_data );
				$this->categories['wd_popup']['data'] = array();
			}

			update_option( 'wd_imported_data_' . $version, $imported_data, false );
		}

		wp_send_json(
			array(
				'content' => $this->popup_content( true, 'remove' ),
			)
		);
	}

	/**
	 * Delete presets.
	 */
	private function delete_presets() {
		$presets = get_option( 'xts-options-presets' );

		if ( ! $presets ) {
			return;
		}

		foreach ( $presets as $preset ) {
			Presets::get_instance()->remove_preset( $preset['id'] );
		}
	}

	/**
	 * Delete headers.
	 *
	 * @param array $imported_data Data.
	 *
	 * @return array
	 */
	private function delete_headers( $imported_data ) {
		$saved_headers = get_option( 'whb_saved_headers' );

		if ( ! isset( $imported_data['headers'] ) ) {
			return $imported_data;
		}

		foreach ( $imported_data['headers'] as $key => $header_id ) {
			unset( $saved_headers[ $header_id ] );
			unset( $imported_data['headers'][ $key ] );

			delete_option( 'whb_' . $header_id );
			delete_option( 'xts-' . $header_id . '-file-data' );
			delete_option( 'xts-' . $header_id . '-css-data' );
			delete_option( 'xts-' . $header_id . '-version' );
			delete_option( 'xts-' . $header_id . '-site-url' );
			delete_option( 'xts-' . $header_id . '-status' );
			delete_option( 'xts_' . $header_id );
		}

		update_option( 'whb_saved_headers', $saved_headers );
		update_option( 'whb_main_header', 'default_header' );

		return $imported_data;
	}

	/**
	 * Delete posts.
	 *
	 * @param array $post_types    Post types to delete.
	 * @param array $imported_data Data.
	 *
	 * @return array
	 */
	private function delete_posts( $post_types, $imported_data ) {
		$deleted_ids = array();

		foreach ( $post_types as $post_type ) {
			if ( ! isset( $imported_data[ $post_type ] ) ) {
				continue;
			}

			foreach ( $imported_data[ $post_type ] as $key => $post ) {
				unset( $imported_data[ $post_type ][ $key ] );
				wp_delete_post( $post['new'], true );
				$deleted_ids[] = $post['new'];
			}
		}

		if ( isset( $imported_data['all_posts'] ) ) {
			foreach ( $imported_data['all_posts'] as $key => $post ) {
				if ( ! in_array( $post['post_type'], $post_types, true ) ) {
					continue;
				}

				unset( $imported_data['all_posts'][ $key ] );
			}
		}

		$this->remove_from_replaced_items( $deleted_ids );

		return $imported_data;
	}

	/**
	 * Remove post IDs from wd_import_replaced_items option.
	 *
	 * @param array $post_ids Post IDs to remove.
	 */
	private function remove_from_replaced_items( array $post_ids ) {
		if ( empty( $post_ids ) ) {
			return;
		}

		$data = get_option( 'wd_import_replaced_items', array() );

		foreach ( $post_ids as $id ) {
			unset( $data[ $id ] );
		}

		update_option( 'wd_import_replaced_items', $data, false );
	}

	/**
	 * Delete terms.
	 *
	 * @param array $taxonomies    Tax to delete.
	 * @param array $imported_data Data.
	 *
	 * @return array
	 */
	private function delete_terms( $taxonomies, $imported_data ) {
		if ( ! isset( $imported_data['term'] ) ) {
			return $imported_data;
		}

		foreach ( $imported_data['term'] as $taxonomy => $data ) {
			if ( ! in_array( $taxonomy, $taxonomies, true ) ) {
				continue;
			}

			foreach ( $data as $term ) {
				unset( $imported_data['term'][ $taxonomy ][ $term['old'] ] );
				wp_delete_term( $term['new'], $taxonomy );
			}
		}

		return $imported_data;
	}

	/**
	 * Interface.
	 */
	public function render() {
		?>
		<div class="xts-popup-holder xts-import-remove">
			<a href="#" class="xts-popup-opener xts-import-remove-opener xts-bordered-btn xts-color-warning xts-i-trash">
				<?php esc_html_e( 'Remove content', 'woodmart' ); ?>
			</a>

			<div class="xts-popup-overlay"></div>

			<div class="xts-popup xts-theme-style">
				<div class="xts-popup-inner">
					<div class="xts-popup-header">
						<div class="xts-popup-title">
							<?php esc_html_e( 'Remove content', 'woodmart' ); ?>
						</div>

						<a href="" class="xts-popup-close xts-i-close">
							<?php esc_html_e( 'Close', 'woodmart' ); ?>
						</a>
					</div>

					<div class="xts-popup-content xts-import-remove-content ">
						<div class="xts-notices-wrapper xts-import-notices xts-import-remove-notices"></div>

						<div class="xts-import-remove-form-wrap">
							<?php $this->popup_content( false, 'import' ); ?>
						</div>
					</div>

					<div class="xts-popup-actions"> </div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Popup content.
	 *
	 * @param bool   $ajax   In AJAX.
	 * @param string $action Action name.
	 *
	 * @return false|string|void
	 */
	public function popup_content( $ajax, $action ) {
		$this->set_categories_data();
		$this->remove_options();

		$attrs = '';

		if ( 'import' === $action ) {
			$attrs .= ' checked';
		}

		if ( $ajax ) {
			ob_start();
		}

		?>
		<form class="xts-import-remove-form" method="post" action="#">
			<div class="xts-import-select-btns">
				<button class="xts-import-remove-select xts-inline-btn xts-i-check-all">
					<?php esc_html_e( 'Check all', 'woodmart' ); ?>
				</button>

				<button class="xts-import-remove-deselect xts-inline-btn xts-i-uncheck-all">
					<?php esc_html_e( 'Uncheck all', 'woodmart' ); ?>
				</button>
			</div>

			<?php foreach ( $this->categories as $key => $category ) : ?>
				<?php
				$count = count( $category['data'] );

				$loop_attrs = '';

				if ( 0 === $count ) {
					$loop_attrs .= ' disabled';
				} else {
					$loop_attrs .= $attrs;
				}

				?>
				<div class="xts-import-remove-items">
					<input type="checkbox" <?php echo esc_attr( $loop_attrs ); ?> name="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $key ); ?>">

					<label for="<?php echo esc_attr( $key ); ?>">
						<?php echo esc_html( $category['title'] ); ?>
						<span><?php echo esc_html( '(' . $count . ')' ); ?></span>
					</label>
				</div>
			<?php endforeach; ?>

			<div class="xts-import-remove-alert">
				<p>
					<?php echo wp_kses( __( '<strong>Warning</strong>. You are going to completely delete the content imported with our theme. This process cannot be undone. Any changes you made in import pages, posts, or products will be lost.', 'woodmart' ), woodmart_get_allowed_html() ); ?>
				</p>

				<button type="submit" class="xts-import-remove-btn xts-btn xts-color-warning xts-i-trash">
					<?php esc_html_e( 'Remove', 'woodmart' ); ?>
				</button>
			</div>
		</form>

		<div class="xts-import-remove-img">
			<img src="<?php echo esc_url( WOODMART_ASSETS_IMAGES . '/xts-import-image.jpg' ); ?>" alt="<?php esc_attr_e( 'Remove image', 'woodmart' ); ?>" loading="lazy">
		</div>
		<?php
		if ( $ajax ) {
			return ob_get_clean();
		}
	}

	/**
	 * Has data to remove.
	 *
	 * @return array|bool
	 */
	public function has_data_to_remove() {
		$this->set_categories_data();

		return $this->has_data_to_remove;
	}

	/**
	 * Get partial version slugs for a parent version.
	 *
	 * @param string $parent_version Parent version slug.
	 * @return array
	 */
	private function get_partial_version_slugs( $parent_version ) {
		$versions      = woodmart_get_config( 'versions' );
		$partial_slugs = array();

		if ( empty( $versions[ $parent_version ]['partial'] ) ) {
			return $partial_slugs;
		}

		foreach ( $versions[ $parent_version ]['partial'] as $partial_items ) {
			foreach ( $partial_items as $partial_slug => $partial_item ) {
				$partial_slugs[] = $partial_slug;
			}
		}

		return $partial_slugs;
	}

	/**
	 * Set categories data filtered to a specific parent version's partial slugs.
	 *
	 * @param string $parent_version Parent version slug.
	 */
	private function set_partial_categories_data( $parent_version ) {
		$partial_slugs = $this->get_partial_version_slugs( $parent_version );

		$this->set_categories();

		foreach ( $partial_slugs as $version ) {
			$imported_data = get_option( 'wd_imported_data_' . $version );

			if ( ! empty( $imported_data['term']['nav_menu'] ) ) {
				$this->has_data_to_remove             = true;
				$this->categories['nav_menu']['data'] = array_replace( $this->categories['nav_menu']['data'], $imported_data['term']['nav_menu'] );
			}

			if ( ! empty( $imported_data['page'] ) ) {
				$this->has_data_to_remove         = true;
				$this->categories['page']['data'] = array_replace( $this->categories['page']['data'], $imported_data['page'] );
			}

			if ( ! empty( $imported_data['attachment'] ) ) {
				$this->has_data_to_remove               = true;
				$this->categories['attachment']['data'] = array_replace( $this->categories['attachment']['data'], $imported_data['attachment'] );
			}

			if ( ! empty( $imported_data['woodmart_layout'] ) ) {
				$this->has_data_to_remove                    = true;
				$this->categories['woodmart_layout']['data'] = array_replace( $this->categories['woodmart_layout']['data'], $imported_data['woodmart_layout'] );
			}

			if ( ! empty( $imported_data['headers'] ) ) {
				$this->has_data_to_remove            = true;
				$this->categories['headers']['data'] = array_replace( $this->categories['headers']['data'], $imported_data['headers'] );
			}

			if ( ! empty( $imported_data['term']['woodmart_slider'] ) ) {
				$this->has_data_to_remove                    = true;
				$this->categories['woodmart_slider']['data'] = array_replace( $this->categories['woodmart_slider']['data'], $imported_data['term']['woodmart_slider'] );
			}

			if ( ! empty( $imported_data['post'] ) ) {
				$this->has_data_to_remove         = true;
				$this->categories['post']['data'] = array_replace( $this->categories['post']['data'], $imported_data['post'] );
			}

			if ( ! empty( $imported_data['portfolio'] ) ) {
				$this->has_data_to_remove              = true;
				$this->categories['portfolio']['data'] = array_replace( $this->categories['portfolio']['data'], $imported_data['portfolio'] );
			}

			if ( ! empty( $imported_data['product'] ) ) {
				$this->has_data_to_remove            = true;
				$this->categories['product']['data'] = array_replace( $this->categories['product']['data'], $imported_data['product'] );
			}

			if ( ! empty( $imported_data['cms_block'] ) ) {
				$this->has_data_to_remove              = true;
				$this->categories['cms_block']['data'] = array_replace( $this->categories['cms_block']['data'], $imported_data['cms_block'] );
			}

			if ( ! empty( $imported_data['mc4wp-form'] ) ) {
				$this->has_data_to_remove               = true;
				$this->categories['mc4wp-form']['data'] = array_replace( $this->categories['mc4wp-form']['data'], $imported_data['mc4wp-form'] );
			}

			if ( ! empty( $imported_data['wpcf7_contact_form'] ) ) {
				$this->has_data_to_remove                       = true;
				$this->categories['wpcf7_contact_form']['data'] = array_replace( $this->categories['wpcf7_contact_form']['data'], $imported_data['wpcf7_contact_form'] );
			}

			if ( ! empty( $imported_data['wd_floating_block'] ) ) {
				$this->has_data_to_remove                      = true;
				$this->categories['wd_floating_block']['data'] = array_replace( $this->categories['wd_floating_block']['data'], $imported_data['wd_floating_block'] );
			}

			if ( ! empty( $imported_data['wd_popup'] ) ) {
				$this->has_data_to_remove             = true;
				$this->categories['wd_popup']['data'] = array_replace( $this->categories['wd_popup']['data'], $imported_data['wd_popup'] );
			}

			if ( ! empty( $imported_data['presets'] ) ) {
				$this->has_data_to_remove            = true;
				$this->categories['presets']['data'] = array_replace( $this->categories['presets']['data'], $imported_data['presets'] );
			}
		}
	}

	/**
	 * Partial remove AJAX action — removes only content from the given parent version's partial slugs.
	 */
	public function partial_remove_action() {
		check_ajax_referer( 'woodmart-import-remove-nonce', 'security' );

		if ( ! isset( $_GET['data'] ) || ! $_GET['data'] ) { // phpcs:ignore
			return;
		}

		if ( empty( $_GET['parent_version'] ) ) { // phpcs:ignore
			return;
		}

		$parent_version = sanitize_text_field( wp_unslash( $_GET['parent_version'] ) ); // phpcs:ignore
		$partial_slugs  = $this->get_partial_version_slugs( $parent_version );

		$selected_categories_raw = woodmart_clean( wp_unslash( $_GET['data'] ) ); // phpcs:ignore
		$selected_categories     = array();

		foreach ( $selected_categories_raw as $category ) {
			$selected_categories[] = $category['name'];
		}

		$this->set_categories();

		foreach ( $partial_slugs as $version ) {
			$imported_data = get_option( 'wd_imported_data_' . $version );

			if ( in_array( 'page', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'page' ), $imported_data );

				$this->categories['page']['data'] = array();
			}

			if ( in_array( 'attachment', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'attachment' ), $imported_data );

				$this->categories['attachment']['data'] = array();
			}

			if ( in_array( 'woodmart_layout', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'woodmart_layout' ), $imported_data );

				$this->categories['woodmart_layout']['data'] = array();
			}

			if ( in_array( 'headers', $selected_categories, true ) ) {
				$imported_data = $this->delete_headers( $imported_data );

				$this->categories['headers']['data'] = array();
			}

			if ( in_array( 'woodmart_slider', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms( array( 'woodmart_slider' ), $imported_data );
				$imported_data = $this->delete_posts( array( 'woodmart_slide' ), $imported_data );

				$this->categories['woodmart_slider']['data'] = array();
			}

			if ( in_array( 'post', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms( array( 'category', 'post_tag' ), $imported_data );
				$imported_data = $this->delete_posts( array( 'post' ), $imported_data );

				$this->categories['post']['data'] = array();
			}

			if ( in_array( 'portfolio', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms( array( 'project-cat' ), $imported_data );
				$imported_data = $this->delete_posts( array( 'portfolio' ), $imported_data );

				$this->categories['portfolio']['data'] = array();
			}

			if ( in_array( 'product', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms(
					array(
						'product_cat',
						'product_brand',
						'pa_brand',
						'pa_color',
						'pa_size',
					),
					$imported_data
				);
				$imported_data = $this->delete_posts(
					array(
						'product',
						'product_variation',
						'woodmart_size_guide',
						'woodmart_woo_lv',
						'woodmart_woo_fbt',
						'wd_woo_discounts',
						'wd_product_tabs',
						'wd_custom_label',
					),
					$imported_data
				);

				$this->categories['product']['data'] = array();
			}

			if ( in_array( 'cms_block', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'cms_block' ), $imported_data );

				$this->categories['cms_block']['data'] = array();
			}

			if ( in_array( 'nav_menu', $selected_categories, true ) ) {
				$imported_data = $this->delete_terms( array( 'nav_menu' ), $imported_data );
				$imported_data = $this->delete_posts( array( 'nav_menu_item' ), $imported_data );

				$this->categories['nav_menu']['data'] = array();
			}

			if ( in_array( 'mc4wp-form', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'mc4wp-form' ), $imported_data );

				$this->categories['mc4wp-form']['data'] = array();
			}

			if ( in_array( 'wpcf7_contact_form', $selected_categories, true ) ) {
				$imported_data = $this->delete_posts( array( 'wpcf7_contact_form' ), $imported_data );

				$this->categories['wpcf7_contact_form']['data'] = array();
			}

			if ( in_array( 'wd_floating_block', $selected_categories, true ) ) {
				$imported_data                                 = $this->delete_posts( array( 'wd_floating_block' ), $imported_data );
				$this->categories['wd_floating_block']['data'] = array();
			}

			if ( in_array( 'wd_popup', $selected_categories, true ) ) {
				$imported_data                        = $this->delete_posts( array( 'wd_popup' ), $imported_data );
				$this->categories['wd_popup']['data'] = array();
			}

			if ( in_array( 'presets', $selected_categories, true ) && ! empty( $imported_data['presets'] ) ) {
				foreach ( $imported_data['presets'] as $preset ) {
					Presets::get_instance()->remove_preset( $preset['id'] );
				}

				$imported_data['presets']            = array();
				$this->categories['presets']['data'] = array();
			}

			update_option( 'wd_imported_data_' . $version, $imported_data, false );
		}

		if ( in_array( 'page', $selected_categories, true ) ) {
			$imported_versions = get_option( 'wd_import_imported_versions', array() );

			foreach ( $partial_slugs as $slug ) {
				$key = array_search( $slug, $imported_versions, true );
				if ( false !== $key ) {
					unset( $imported_versions[ $key ] );
				}
			}

			update_option( 'wd_import_imported_versions', array_values( $imported_versions ), false );
		}

		wp_send_json(
			array(
				'content' => $this->partial_popup_content( true, 'remove', $parent_version ),
			)
		);
	}

	/**
	 * Render partial remove popup for a given parent version.
	 *
	 * @param string $parent_version Parent version slug.
	 */
	public function render_partial( $parent_version ) {
		?>
		<div class="xts-popup-holder xts-import-partial-remove" data-parent-version="<?php echo esc_attr( $parent_version ); ?>">
			<a href="#" class="xts-popup-opener xts-import-partial-remove-opener xts-bordered-btn xts-color-warning xts-i-trash">
				<?php esc_html_e( 'Remove content', 'woodmart' ); ?>
			</a>

			<div class="xts-popup-overlay"></div>

			<div class="xts-popup xts-theme-style">
				<div class="xts-popup-inner">
					<div class="xts-popup-header">
						<div class="xts-popup-title">
							<?php
							$versions   = woodmart_get_config( 'versions' );
							$demo_title = isset( $versions[ $parent_version ]['title'] ) ? $versions[ $parent_version ]['title'] : '';
							if ( $demo_title ) {
								/* translators: %s: Demo title */
								echo esc_html( sprintf( __( 'Remove %s content', 'woodmart' ), $demo_title ) );
							} else {
								esc_html_e( 'Remove content', 'woodmart' );
							}
							?>
						</div>

						<a href="" class="xts-popup-close xts-i-close">
							<?php esc_html_e( 'Close', 'woodmart' ); ?>
						</a>
					</div>

					<div class="xts-popup-content xts-import-remove-content">
						<div class="xts-notices-wrapper xts-import-notices xts-import-partial-remove-notices"></div>

						<div class="xts-import-remove-form-wrap">
							<?php $this->partial_popup_content( false, 'import', $parent_version ); ?>
						</div>
					</div>

					<div class="xts-popup-actions"> </div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Partial popup content — shows only data from the given parent version's partial slugs.
	 *
	 * @param bool   $ajax           Whether called from AJAX.
	 * @param string $action         'import' or 'remove'.
	 * @param string $parent_version Parent version slug.
	 *
	 * @return false|string|void
	 */
	public function partial_popup_content( $ajax, $action, $parent_version ) {
		$this->has_data_to_remove = false;
		$this->categories         = array();
		$this->set_partial_categories_data( $parent_version );

		$attrs = '';

		if ( 'import' === $action ) {
			$attrs .= ' checked';
		}

		if ( $ajax ) {
			ob_start();
		}

		?>
		<form class="xts-import-remove-form" method="post" action="#" data-parent-version="<?php echo esc_attr( $parent_version ); ?>">
			<div class="xts-import-select-btns">
				<button class="xts-import-partial-remove-select xts-inline-btn xts-i-check-all">
					<?php esc_html_e( 'Check all', 'woodmart' ); ?>
				</button>

				<button class="xts-import-partial-remove-deselect xts-inline-btn xts-i-uncheck-all">
					<?php esc_html_e( 'Uncheck all', 'woodmart' ); ?>
				</button>
			</div>

			<?php foreach ( $this->categories as $key => $category ) : ?>
				<?php
				$count = count( $category['data'] );

				$loop_attrs = '';

				if ( 0 === $count ) {
					$loop_attrs .= ' disabled';
				} else {
					$loop_attrs .= $attrs;
				}

				?>
				<div class="xts-import-remove-items">
					<input type="checkbox" <?php echo esc_attr( $loop_attrs ); ?> name="<?php echo esc_attr( $key ); ?>" id="partial-<?php echo esc_attr( $key ); ?>-<?php echo esc_attr( $parent_version ); ?>">

					<label for="partial-<?php echo esc_attr( $key ); ?>-<?php echo esc_attr( $parent_version ); ?>">
						<?php echo esc_html( $category['title'] ); ?>
						<span><?php echo esc_html( '(' . $count . ')' ); ?></span>
					</label>
				</div>
			<?php endforeach; ?>

			<div class="xts-import-remove-alert">
				<p>
					<?php echo wp_kses( __( '<strong>Warning</strong>. You are going to completely delete the partial content imported from the chosen predefined website. This process cannot be undone. Any changes you made to the imported pages will be lost.', 'woodmart' ), woodmart_get_allowed_html() ); ?>
				</p>

				<?php if ( $this->has_data_to_remove ) : ?>
					<button type="submit" class="xts-import-partial-remove-btn xts-btn xts-color-warning xts-i-trash">
						<?php esc_html_e( 'Remove', 'woodmart' ); ?>
					</button>
				<?php endif; ?>
			</div>
		</form>

		<div class="xts-import-remove-img">
			<img loading="lazy" src="<?php echo esc_url( WOODMART_DUMMY_URL . $parent_version . '/preview.jpg' ); ?>" alt="<?php esc_attr_e( 'Remove image', 'woodmart' ); ?>">
		</div>
		<?php

		if ( $ajax ) {
			return ob_get_clean();
		}
	}

	/**
	 * Set categories.
	 */
	public function set_categories() {
		$this->categories = array(
			'page'               => array(
				'title' => esc_html__( 'Pages', 'woodmart' ),
				'data'  => array(),
			),
			'product'            => array(
				'title' => esc_html__( 'Products', 'woodmart' ),
				'data'  => array(),
			),
			'mc4wp-form'         => array(
				'title' => esc_html__( 'Mailchimp forms', 'woodmart' ),
				'data'  => array(),
			),
			'post'               => array(
				'title' => esc_html__( 'Posts', 'woodmart' ),
				'data'  => array(),
			),
			'woodmart_layout'    => array(
				'title' => esc_html__( 'Layouts', 'woodmart' ),
				'data'  => array(),
			),
			'woodmart_slider'    => array(
				'title' => esc_html__( 'Sliders', 'woodmart' ),
				'data'  => array(),
			),
			'portfolio'          => array(
				'title' => esc_html__( 'Projects', 'woodmart' ),
				'data'  => array(),
			),
			'presets'            => array(
				'title' => esc_html__( 'Settings presets', 'woodmart' ),
				'data'  => array(),
			),
			'cms_block'          => array(
				'title' => esc_html__( 'HTML blocks', 'woodmart' ),
				'data'  => array(),
			),
			'headers'            => array(
				'title' => esc_html__( 'Headers', 'woodmart' ),
				'data'  => array(),
			),
			'attachment'         => array(
				'title' => esc_html__( 'Images', 'woodmart' ),
				'data'  => array(),
			),
			'nav_menu'           => array(
				'title' => esc_html__( 'Menu', 'woodmart' ),
				'data'  => array(),
			),
			'wpcf7_contact_form' => array(
				'title' => esc_html__( 'Contact forms', 'woodmart' ),
				'data'  => array(),
			),
			'wd_floating_block'  => array(
				'title' => esc_html__( 'Floating blocks', 'woodmart' ),
				'data'  => array(),
			),
			'wd_popup'           => array(
				'title' => esc_html__( 'Popups', 'woodmart' ),
				'data'  => array(),
			),
		);
	}

	/**
	 * Set counts.
	 */
	private function set_categories_data() {
		$presets = get_option( 'xts-options-presets' );
		if ( $presets ) {
			$this->has_data_to_remove            = true;
			$this->categories['presets']['data'] = get_option( 'xts-options-presets' );
		}

		foreach ( $this->versions as $version ) {
			$imported_data = get_option( 'wd_imported_data_' . $version );

			if ( ! empty( $imported_data['term']['nav_menu'] ) ) {
				$this->has_data_to_remove             = true;
				$this->categories['nav_menu']['data'] = array_replace( $this->categories['nav_menu']['data'], $imported_data['term']['nav_menu'] );
			}

			if ( ! empty( $imported_data['page'] ) ) {
				$this->has_data_to_remove         = true;
				$this->categories['page']['data'] = array_replace( $this->categories['page']['data'], $imported_data['page'] );
			}

			if ( ! empty( $imported_data['attachment'] ) ) {
				$this->has_data_to_remove               = true;
				$this->categories['attachment']['data'] = array_replace( $this->categories['attachment']['data'], $imported_data['attachment'] );
			}

			if ( ! empty( $imported_data['woodmart_layout'] ) ) {
				$this->has_data_to_remove                    = true;
				$this->categories['woodmart_layout']['data'] = array_replace( $this->categories['woodmart_layout']['data'], $imported_data['woodmart_layout'] );
			}

			if ( ! empty( $imported_data['headers'] ) ) {
				$this->has_data_to_remove            = true;
				$this->categories['headers']['data'] = array_replace( $this->categories['headers']['data'], $imported_data['headers'] );
			}

			if ( ! empty( $imported_data['term']['woodmart_slider'] ) ) {
				$this->has_data_to_remove                    = true;
				$this->categories['woodmart_slider']['data'] = array_replace( $this->categories['woodmart_slider']['data'], $imported_data['term']['woodmart_slider'] );
			}

			if ( ! empty( $imported_data['post'] ) ) {
				$this->has_data_to_remove         = true;
				$this->categories['post']['data'] = array_replace( $this->categories['post']['data'], $imported_data['post'] );
			}

			if ( ! empty( $imported_data['portfolio'] ) ) {
				$this->has_data_to_remove              = true;
				$this->categories['portfolio']['data'] = array_replace( $this->categories['portfolio']['data'], $imported_data['portfolio'] );
			}

			if ( ! empty( $imported_data['product'] ) ) {
				$this->has_data_to_remove            = true;
				$this->categories['product']['data'] = array_replace( $this->categories['product']['data'], $imported_data['product'] );
			}

			if ( ! empty( $imported_data['cms_block'] ) ) {
				$this->has_data_to_remove              = true;
				$this->categories['cms_block']['data'] = array_replace( $this->categories['cms_block']['data'], $imported_data['cms_block'] );
			}

			if ( ! empty( $imported_data['mc4wp-form'] ) ) {
				$this->has_data_to_remove               = true;
				$this->categories['mc4wp-form']['data'] = array_replace( $this->categories['mc4wp-form']['data'], $imported_data['mc4wp-form'] );
			}

			if ( ! empty( $imported_data['wpcf7_contact_form'] ) ) {
				$this->has_data_to_remove                       = true;
				$this->categories['wpcf7_contact_form']['data'] = array_replace( $this->categories['wpcf7_contact_form']['data'], $imported_data['wpcf7_contact_form'] );
			}

			if ( ! empty( $imported_data['wd_floating_block'] ) ) {
				$this->has_data_to_remove                      = true;
				$this->categories['wd_floating_block']['data'] = array_replace( $this->categories['wd_floating_block']['data'], $imported_data['wd_floating_block'] );
			}

			if ( ! empty( $imported_data['wd_popup'] ) ) {
				$this->has_data_to_remove             = true;
				$this->categories['wd_popup']['data'] = array_replace( $this->categories['wd_popup']['data'], $imported_data['wd_popup'] );
			}
		}
	}
}

Remove::get_instance();
