<?php
/**
 * Plugins template.
 *
 * @package woodmart
 */

use XTS\Admin\Modules\Setup_Wizard;
use XTS\Admin\Modules\Setup_Wizard\Install_Plugins;

if ( isset( $_GET['wd_builder'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$builder = sanitize_key( wp_unslash( $_GET['wd_builder'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
} elseif ( woodmart_get_current_page_builder() ) {
	$builder = woodmart_get_current_page_builder();
} else {
	$builder = 'elementor';
}

$dashboard       = Setup_Wizard::get_instance();
$install_plugins = Install_Plugins::get_instance();

$plugins_list = $install_plugins->get_plugins();

?>
<div class="xts-plugins<?php echo ! count( $install_plugins->get_required_plugins_to_activate() ) ? ' xts-required-active' : ''; ?>">
	<div class="xts-plugin-response"></div>

	<?php if ( $dashboard->is_setup() ) : ?>
		<h3>
			<?php esc_html_e( 'Plugins activation', 'woodmart' ); ?>
		</h3>

		<p>
			<?php esc_html_e( 'Install and activate essential plugins for your website.', 'woodmart' ); ?>
		</p>
	<?php endif; ?>

	<ul>
		<?php foreach ( $plugins_list as $slug => $plugin_data ) : ?>
			<?php $image_url = isset( $plugin_data['image'] ) ? $plugin_data['image'] : $slug . '.svg'; ?>
			<li class="xts-plugin-wrapper<?php echo isset( $plugin_data['description'] ) ? ' xts-large' : ''; ?>">
				<div class="xts-plugin-heading">
					<div class="xts-plugin-img">
						<img src="<?php echo esc_url( $dashboard->get_plugin_image_url( $image_url ) ); ?>" alt="plugin logo">
					</div>

					<span class="xts-plugin-name">
						<?php echo esc_html( $plugin_data['name'] ); ?>
					</span>
				</div>

					<span class="xts-plugin-required">
						<?php if ( ! empty( $plugin_data['required'] ) || 'elementor' === $slug || 'js_composer' === $slug ) : ?>
							<span class="xts-plugin-required-dot"></span>
							<span class="xts-plugin-required-text">
								<?php esc_html_e( 'Required', 'woodmart' ); ?>
							</span>
						<?php endif; ?>
					</span>

				<?php if ( ! empty( $plugin_data['description'] ) ) : ?>
					<div class="xts-plugin-description">
						<?php echo esc_html( $plugin_data['description'] ); ?>
					</div>
				<?php endif; ?>

				<span class="xts-plugin-version">
					<?php if ( ! empty( $plugin_data['version'] ) ) : ?>
						<span>
							<?php echo esc_html( $plugin_data['version'] ); ?>
						</span>
					<?php endif; ?>
				</span>

				<div class="xts-plugin-btn-wrapper">
					<?php if ( is_multisite() && isset( $plugin_data['file_path'] ) && is_plugin_active_for_network( $plugin_data['file_path'] ) ) : ?>
						<span class="xts-plugin-btn-text">
							<?php esc_html_e( 'Plugin activated globally.', 'woodmart' ); ?>
						</span>
					<?php elseif ( isset( $plugin_data['status'] ) && $dashboard->is_setup() && 'deactivate' === $plugin_data['status'] ) : ?>
						<span class="xts-plugin-btn-text">
							<?php esc_html_e( 'Activated', 'woodmart' ); ?>
						</span>
					<?php elseif ( isset( $plugin_data['status'] ) && 'require_update' !== $plugin_data['status'] ) : ?>
						<a class="xts-btn xts-ajax-plugin xts-<?php echo esc_html( $plugin_data['status'] ); ?>"
							href="<?php echo esc_url( $install_plugins->get_action_url( $slug, $plugin_data['status'] ) ); ?>"
							data-plugin="<?php echo esc_attr( $slug ); ?>"
							data-builder="<?php echo esc_attr( $builder ); ?>"
							data-action="<?php echo esc_attr( $plugin_data['status'] ); ?>">
							<span><?php echo esc_html( $install_plugins->get_action_text( $plugin_data['status'] ) ); ?></span>
						</a>
					<?php elseif ( $dashboard->is_setup() ) : ?>
						<span class="xts-plugin-btn-text">
							<?php esc_html_e( 'Required update not available', 'woodmart' ); ?>
						</span>
					<?php endif; ?>

					<?php if ( isset( $plugin_data['buttons'] ) ) : ?>
						<?php foreach ( $plugin_data['buttons'] as $button ) : ?>
							<a href="<?php echo esc_url( $button['url'] ); ?>" class="xts-btn<?php echo isset( $button['extra-class'] ) ? ' ' . esc_attr( $button['extra-class'] ) : ''; ?>">
								<?php echo esc_html( $button['name'] ); ?>
							</a>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</li>
		<?php endforeach; ?>
	</ul>

	<?php if ( $dashboard->is_setup() ) : ?>
		<div class="xts-step-actions">
			<a class="xts-btn xts-color-primary xts-wizard-all-plugins" href="#">
				<?php esc_html_e( 'Install & activate all', 'woodmart' ); ?>
			</a>
			<?php $dashboard->get_next_button( 'prebuilt-websites', '', count( $install_plugins->get_required_plugins_to_activate() ) > 0 ); ?>
		</div>
	<?php endif; ?>

	<?php if ( $plugins_list ) : ?>
		<script>
			var xtsPluginsData = <?php echo wp_json_encode( $plugins_list ); ?>
		</script>
	<?php endif; ?>
</div>
