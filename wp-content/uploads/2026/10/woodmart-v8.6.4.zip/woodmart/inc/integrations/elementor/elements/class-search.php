<?php
/**
 * Search map.
 *
 * @package woodmart
 */

namespace XTS\Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

/**
 * Elementor widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Search extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 */
	public function get_name() {
		return 'wd_search';
	}

	/**
	 * Get widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 */
	public function get_title() {
		return esc_html__( 'AJAX Search', 'woodmart' );
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 */
	public function get_icon() {
		return 'wd-icon-search';
	}

	/**
	 * Get widget categories.
	 *
	 * @return array Widget categories.
	 * @since 1.0.0
	 * @access public
	 */
	public function get_categories() {
		return array( 'wd-elements' );
	}

	/**
	 * Register the widget controls.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		/**
		 * Content tab.
		 */

		/**
		 * General settings.
		 */
		$this->start_controls_section(
			'general_content_section',
			array(
				'label' => esc_html__( 'General', 'woodmart' ),
			)
		);

		$this->add_control(
			'number',
			array(
				'label'   => esc_html__( 'Number results to show', 'woodmart' ),
				'default' => 12,
				'type'    => Controls_Manager::NUMBER,
			)
		);

		$this->add_control(
			'search_post_type',
			array(
				'label'   => esc_html__( 'Search post type', 'woodmart' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'product'   => esc_html__( 'Product', 'woodmart' ),
					'post'      => esc_html__( 'Post', 'woodmart' ),
					'portfolio' => esc_html__( 'Portfolio', 'woodmart' ),
				),
				'default' => 'product',
			)
		);

		$this->add_control(
			'price',
			array(
				'label'        => esc_html__( 'Show price', 'woodmart' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '1',
				'label_on'     => esc_html__( 'Yes', 'woodmart' ),
				'label_off'    => esc_html__( 'No', 'woodmart' ),
				'return_value' => '1',
				'condition'    => array(
					'search_post_type' => array( 'product' ),
				),
			)
		);

		$this->add_control(
			'thumbnail',
			array(
				'label'        => esc_html__( 'Show thumbnail', 'woodmart' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '1',
				'label_on'     => esc_html__( 'Yes', 'woodmart' ),
				'label_off'    => esc_html__( 'No', 'woodmart' ),
				'return_value' => '1',
			)
		);

		$this->add_control(
			'category',
			array(
				'label'        => esc_html__( 'Show category', 'woodmart' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '1',
				'label_on'     => esc_html__( 'Yes', 'woodmart' ),
				'label_off'    => esc_html__( 'No', 'woodmart' ),
				'return_value' => '1',
				'condition'    => array(
					'search_post_type' => array( 'product' ),
				),
			)
		);

		$this->add_control(
			'include_cat_search',
			array(
				'label'        => esc_html__( 'Include categories in search', 'woodmart' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '0',
				'label_on'     => esc_html__( 'Yes', 'woodmart' ),
				'label_off'    => esc_html__( 'No', 'woodmart' ),
				'return_value' => '1',
				'condition'    => array(
					'search_post_type' => array( 'product' ),
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Style tab.
		 */

		$this->start_controls_section(
			'color_style_section',
			array(
				'label' => esc_html__( 'Form', 'woodmart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'form_style',
			array(
				'label'   => esc_html__( 'Style', 'woodmart' ),
				'type'    => 'wd_buttons',
				'options' => array(
					'default'   => array(
						'title' => esc_html__( 'Style 1', 'woodmart' ),
						'image' => WOODMART_ASSETS_IMAGES . '/header-builder/search/default.jpg',
						'style' => 'col-2',
					),
					'with-bg'   => array(
						'title' => esc_html__( 'Style 2', 'woodmart' ),
						'image' => WOODMART_ASSETS_IMAGES . '/header-builder/search/with-bg.jpg',
						'style' => 'col-2',
					),
					'with-bg-2' => array(
						'title' => esc_html__( 'Style 3', 'woodmart' ),
						'image' => WOODMART_ASSETS_IMAGES . '/header-builder/search/with-bg-2.jpg',
						'style' => 'col-2',
					),
					'4'         => array(
						'value' => '4',
						'title' => esc_html__( 'Style 4', 'woodmart' ),
						'image' => WOODMART_ASSETS_IMAGES . '/header-builder/search/fourth.jpg',
					),
				),
				'default' => 'default',
			)
		);

		$this->add_responsive_control(
			'form_height',
			array(
				'label'      => esc_html__( 'Form height', 'woodmart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min'  => 30,
						'max'  => 100,
						'step' => 1,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .searchform' => '--wd-form-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'woodmart_color_scheme',
			array(
				'label'   => esc_html__( 'Color scheme', 'woodmart' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					''      => esc_html__( 'Inherit', 'woodmart' ),
					'light' => esc_html__( 'Light', 'woodmart' ),
					'dark'  => esc_html__( 'Dark', 'woodmart' ),
				),
				'default' => '',
			)
		);

		$this->add_control(
			'form_color',
			array(
				'label'     => esc_html__( 'Text color', 'woodmart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .searchform' => '--wd-form-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'form_placeholder_color',
			array(
				'label'     => esc_html__( 'Placeholder color', 'woodmart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .searchform' => '--wd-form-placeholder-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'form_brd_color',
			array(
				'label'     => esc_html__( 'Border color', 'woodmart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .searchform' => '--wd-form-brd-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'form_brd_color_focus',
			array(
				'label'     => esc_html__( 'Border color focus', 'woodmart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .searchform' => '--wd-form-brd-color-focus: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'form_bg',
			array(
				'label'     => esc_html__( 'Background color', 'woodmart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .searchform' => '--wd-form-bg: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'form_shape',
			array(
				'label'     => esc_html__( 'Form shape', 'woodmart' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					''   => array(
						'title' => esc_html__( 'Inherit', 'woodmart' ),
					),
					'0'  => array(
						'title' => esc_html__( 'Square', 'woodmart' ),
					),
					'5'  => array(
						'title' => esc_html__( 'Rounded', 'woodmart' ),
					),
					'35' => array(
						'title' => esc_html__( 'Round', 'woodmart' ),
					),
				),
				'selectors' => array(
					'{{WRAPPER}}' => '--wd-form-brd-radius: {{VALUE}}px;',
				),
				'default'   => '',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'category_style_section',
			array(
				'label'     => esc_html__( 'Category', 'woodmart' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'category'         => '1',
					'search_post_type' => array( 'product' ),
				),
			)
		);

		$this->add_control(
			'cat_selector_style',
			array(
				'label'   => esc_html__( 'Categories selector style', 'woodmart' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'default'   => esc_html__( 'Default', 'woodmart' ),
					'bordered'  => esc_html__( 'Bordered', 'woodmart' ),
					'separated' => esc_html__( 'Separated', 'woodmart' ),
				),
				'default' => 'bordered',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$default_settings = array(
			'number'                => 3,
			'price'                 => 1,
			'thumbnail'             => 1,
			'category'              => 1,
			'include_cat_search'    => 0,
			'search_post_type'      => 'product',
			'woodmart_color_scheme' => 'dark',
			'form_style'            => 'default',
			'cat_selector_style'    => 'bordered',
		);

		$settings = wp_parse_args( $this->get_settings_for_display(), $default_settings );

		$this->add_render_attribute(
			array(
				'wrapper' => array(
					'class' => array(
						'wd-el-search',
						'woodmart-ajax-search',
						'wd-color-' . $settings['woodmart_color_scheme'],
					),
				),
			)
		);

		if ( $settings['woodmart_color_scheme'] ) {
			woodmart_enqueue_inline_style( 'search-opt-color-scheme' );
		}

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
			<?php
			woodmart_search_form(
				array(
					'ajax'               => true,
					'include_cat_search' => $settings['include_cat_search'],
					'post_type'          => $settings['search_post_type'],
					'count'              => $settings['number'],
					'thumbnail'          => $settings['thumbnail'],
					'price'              => $settings['price'],
					'show_categories'    => $settings['category'],
					'search_style'       => $settings['form_style'],
					'cat_selector_style' => $settings['cat_selector_style'],
				)
			);
			?>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Search() );
