<?php
/**
 * Text block map.
 *
 * @package woodmart
 */

namespace XTS\Elementor;

use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Plugin;
use XTS\Modules\HighlightedAnimation\Main as HighlightedAnimation;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

/**
 * Elementor widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Text_Block extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'wd_text_block';
	}

	/**
	 * Get widget Text block.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget Text block.
	 */
	public function get_title() {
		return esc_html__( 'Text block', 'woodmart' );
	}

	/**
	 * Get widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'wd-icon-text-bock';
	}

	/**
	 * Get widget categories.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( 'wd-elements' );
	}

	/**
	 * Register the widget controls.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		/**
		 * Content tab.
		 */

		/**
		 * General settings.
		 */
		$this->start_controls_section(
			'general_content_section',
			array(
				'label' => esc_html__( 'General', 'woodmart' ),
			)
		);

		$this->add_control(
			'text',
			array(
				'label'   => esc_html__( 'Text', 'woodmart' ),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'elementor' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_general_content_section',
			array(
				'label' => esc_html__( 'General', 'woodmart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'text_color_scheme',
			array(
				'label'   => esc_html__( 'Color scheme', 'woodmart' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'inherit' => esc_html__( 'Inherit', 'woodmart' ),
					'light'   => esc_html__( 'Light', 'woodmart' ),
					'dark'    => esc_html__( 'Dark', 'woodmart' ),
				),
				'default' => 'inherit',
			)
		);

		$this->add_control(
			'text_alignment',
			array(
				'label'   => esc_html__( 'Text alignment', 'woodmart' ),
				'type'    => 'wd_buttons',
				'options' => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'woodmart' ),
						'image' => WOODMART_ASSETS_IMAGES . '/settings/align/left.jpg',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'woodmart' ),
						'image' => WOODMART_ASSETS_IMAGES . '/settings/align/center.jpg',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'woodmart' ),
						'image' => WOODMART_ASSETS_IMAGES . '/settings/align/right.jpg',
					),
				),
				'default' => 'left',
			)
		);

		$this->add_responsive_control(
			'width',
			array(
				'label'          => esc_html__( 'Width', 'woodmart' ),
				'type'           => Controls_Manager::SLIDER,
				'default'        => array(
					'unit' => 'px',
				),
				'tablet_default' => array(
					'unit' => 'px',
				),
				'mobile_default' => array(
					'unit' => 'px',
				),
				'size_units'     => array( '%', 'px' ),
				'range'          => array(
					'%'  => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 1000,
					),
				),
				'selectors'      => array(
					'{{WRAPPER}} .wd-text-block' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_paragraph_content_section',
			array(
				'label' => esc_html__( 'Paragraph', 'woodmart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography',
				'label'    => esc_html__( 'Custom typography', 'woodmart' ),
				'selector' => '{{WRAPPER}} .wd-text-block',
			)
		);

		$this->add_control(
			'text_color',
			array(
				'label'   => esc_html__( 'Text color', 'woodmart' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'default' => esc_html__( 'Default', 'woodmart' ),
					'title'   => esc_html__( 'Title', 'woodmart' ),
					'primary' => esc_html__( 'Primary', 'woodmart' ),
					'alt'     => esc_html__( 'Alternative', 'woodmart' ),
					'custom'  => esc_html__( 'Custom', 'woodmart' ),
				),
				'default' => 'default',
			)
		);

		$this->add_control(
			'custom_text_color',
			array(
				'label'     => esc_html__( 'Custom color', 'woodmart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wd-text-block' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'text_color' => 'custom',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_highlight_content_section',
			array(
				'label' => esc_html__( 'Highlight', 'woodmart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_decoration_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				'raw'             => esc_html__( 'The text must be wrapped with the <u></u> tag to highlight it.', 'woodmart' ),
			)
		);

		$this->add_control(
			'highlighted_effect',
			array(
				'label'   => esc_html__( 'Effect', 'woodmart' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'none'     => esc_html__( 'None', 'woodmart' ),
					'rot_text' => esc_html__( 'Rotating Text', 'woodmart' ),
				),
				'default' => 'none',
			)
		);

		$this->add_control(
			'highlighted_animation',
			array(
				'label'     => esc_html__( 'Animation', 'woodmart' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'typing'   => esc_html__( 'Typing', 'woodmart' ),
					'clip'     => esc_html__( 'Clip', 'woodmart' ),
					'slide_up' => esc_html__( 'Slide up', 'woodmart' ),
					'drop_in'  => esc_html__( 'Drop-in', 'woodmart' ),
					'fade'     => esc_html__( 'Fade', 'woodmart' ),
				),
				'default'   => 'typing',
				'condition' => array(
					'highlighted_effect' => 'rot_text',
				),
			)
		);

		$this->add_control(
			'highlighted_duration_time',
			array(
				'label'       => esc_html__( 'Duration (ms)', 'woodmart' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => 600,
				'condition'   => array(
					'highlighted_effect!' => 'none',
				),
			)
		);

		$this->add_control(
			'highlighted_delay_time',
			array(
				'label'       => esc_html__( 'Delay (ms)', 'woodmart' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => 2500,
				'condition'   => array(
					'highlighted_effect!' => 'none',
				),
			)
		);

		$this->add_control(
			'highlighted_effect_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				'raw'             => esc_html__( 'To make the text rotate cyclically, separate each part with a "|" symbol.', 'woodmart' ),
				'condition'       => array(
					'highlighted_effect!' => 'none',
				),
			)
		);

		$this->add_control(
			'highlighted_animation_separator',
			array(
				'type' => Controls_Manager::DIVIDER,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_decoration_typography',
				'label'    => esc_html__( 'Typography', 'woodmart' ),
				'selector' => '{{WRAPPER}} :is(u, .wd-highlight)',
			)
		);

		$this->add_control(
			'title_decoration_color_type',
			array(
				'label'       => esc_html__( 'Color Type', 'elementor' ),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => array(
					'classic'  => array(
						'title' => esc_html__( 'Classic', 'elementor' ),
						'icon'  => 'eicon-paint-brush',
					),
					'gradient' => array(
						'title' => esc_html__( 'Gradient', 'elementor' ),
						'icon'  => 'eicon-barcode',
					),
				),
				'toggle'      => false,
				'default'     => 'classic',
				'render_type' => 'ui',
			)
		);

		$this->add_control(
			'title_decoration_color',
			array(
				'label'     => esc_html__( 'Color', 'woodmart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} :is(u, .wd-highlight)' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'title_decoration_color_type' => 'classic',
				),
			)
		);

		woodmart_elementor_get_gradient_controls_map(
			$this,
			'text',
			'{{WRAPPER}} :is(u, .wd-highlight)',
			array(
				'title_decoration_color_type' => 'gradient',
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'      => 'title_decoration_background',
				'types'     => array( 'classic', 'gradient' ),
				'selector'  => '{{WRAPPER}} :is(u, .wd-highlight)',
				'separator' => 'before',
				'condition' => array(
					'title_decoration_color_type' => 'classic',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'      => 'title_decoration_border',
				'selector'  => '{{WRAPPER}} :is(u, .wd-highlight)',
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'title_decoration_border_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'woodmart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} :is(u, .wd-highlight)' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'title_decoration_box_shadow',
				'selector' => '{{WRAPPER}} :is(u, .wd-highlight)',
			)
		);

		$this->add_responsive_control(
			'title_decoration_padding',
			array(
				'label'      => esc_html__( 'Padding', 'woodmart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} :is(u, .wd-highlight)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'highlighted_vertical_offset',
			array(
				'label'              => esc_html__( 'Vertical offset', 'elementor' ),
				'type'               => Controls_Manager::SLIDER,
				'size_units'         => array( 'px', '%', 'em' ),
				'range'              => array(
					'%'  => array(
						'min' => -100,
						'max' => 100,
					),
					'px' => array(
						'min' => -50,
						'max' => 50,
					),
					'em' => array(
						'min'  => -5,
						'max'  => 5,
						'step' => 0.1,
					),
				),
				'selectors'          => array(
					'{{WRAPPER}}' => '--wd-highlight-offset: {{SIZE}}{{UNIT}};',
				),
				'frontend_available' => true,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$default_settings = array(
			'text_color'                => 'default',
			'text_color_scheme'         => '',
			'text_alignment'            => 'left',
			'width'                     => '',

			'highlighted_effect'        => 'none',
			'highlighted_animation'     => 'typing',
			'highlighted_duration_time' => '',
			'highlighted_delay_time'    => '',
		);

		$settings = wp_parse_args( $this->get_settings_for_display(), $default_settings );

		$this->add_render_attribute(
			array(
				'wrapper' => array(
					'class' => array(
						'wd-text-block reset-last-child',
						'text-' . $settings['text_alignment'],
					),
				),
			)
		);

		if ( 'default' !== $settings['text_color'] && 'custom' !== $settings['text_color'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'color-' . $settings['text_color'] );
		}

		if ( 'inherit' !== $settings['text_color_scheme'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'color-scheme-' . $settings['text_color_scheme'] );
		}

		if ( strpos( $settings['text'], "\n" ) !== false && wp_strip_all_tags( $settings['text'] ) !== $settings['text'] ) {
			$settings['text'] = wpautop( $settings['text'] );
		}

		$this->add_inline_editing_attributes( 'wrapper' );
		$this->add_inline_editing_attributes( 'text' );

		woodmart_enqueue_inline_style( 'text-block' );

		if (
			'none' === $settings['highlighted_effect'] &&
			(
				'' !== $settings['highlighted_vertical_offset']['size'] ||
				'' !== $settings['highlighted_vertical_offset_tablet']['size'] ||
				'' !== $settings['highlighted_vertical_offset_mobile']['size']
			)
		) {
			woodmart_enqueue_inline_style( 'opt-text-highlight-wpb-elem' );
		}

		$content = shortcode_unautop( $settings['text'] );

		if ( 'none' !== $settings['highlighted_effect'] ) {
			$content = HighlightedAnimation::get_instance()->prepare_external( $content, $settings );
		}
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); // phpcs:ignore ?>>
			<?php if ( woodmart_elementor_is_edit_mode() ) : ?>
				<div <?php echo $this->get_render_attribute_string( 'text' ); // phpcs:ignore ?>>
			<?php endif; ?>

			<?php echo do_shortcode( $content ); ?>

			<?php if ( woodmart_elementor_is_edit_mode() ) : ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Text_Block() );
